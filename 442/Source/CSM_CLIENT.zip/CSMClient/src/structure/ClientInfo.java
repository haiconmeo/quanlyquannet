/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package structure;

/**
 *
 * @author Killua
 */
public class ClientInfo {
    private String ID;
    private String IP;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }
    
    
}
