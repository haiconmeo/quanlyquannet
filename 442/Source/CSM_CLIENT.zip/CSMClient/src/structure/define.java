/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package structure;

/**
 *
 * @author Mr.Tran
 */
public final class define {
    public static final String     SUCCESS  = "111";
    public static final String     FAIL     = "222";
    public static final int        SERVER_PORT = 10000;
    public static final int        CMD_CLIENT_PORT = 11111;
    public static final int        CMD_DESKTOP_PORT = 22222;
}
