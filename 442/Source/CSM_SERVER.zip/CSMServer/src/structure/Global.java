/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package structure;

import Action.SetTime;

/**
 *
 * @author Mr.Tran
 */
public class Global {
    public static csmserver.CsmserverGui mainGui = null;
    public static SetTime threadtime = null;
}
